package com.test;

import com.aomei.util.JCO3.RfcManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoStructure;
import com.sap.conn.jco.JCoTable;

public class TestJCO {
 
	public static void main(String[] args) throws JCoException {
//		      JCO3 jco = new JCO3();
//		      jco.connectWithPooled();
		    
		        // ��ȡRFC ����
		        JCoFunction function = RfcManager.getFunction("ZYJFHTZS");
		        // ����import �����ֶ�
		        JCoParameterList importParam = function.getImportParameterList();
		        
		        importParam.setValue("I_VBELN_VL", "80144151");
		        // ִ��RFC
		        RfcManager.execute(function);

		        // ��ȡRFC���ص��ֶ�ֵ
//		        JCoParameterList exportParam = function.getExportParameterList();
//		        String exParamA = exportParam.getString("field_A");
//		        String exParamB = exportParam.getString("field_B");
		        //��ȡRFC���ӵĽṹ
		        JCoStructure exportStructure = function.getExportParameterList() .getStructure("GT_HEADER"); 
		        System.out.println(exportStructure.getString("VBELN"));   
		        // ����RFC���صı�����
		        JCoTable tb = function.getTableParameterList().getTable("GT_DETAIL");
		        for (int i = 0; i < tb.getNumRows(); i++) {
		            tb.setRow(i);
		            System.out.println(tb.getString("ARKTX"));
		            System.out.println(tb.getString("POSNR"));
		            System.out.println(tb.getString("MATNR"));
		            
		        }
		      
	   }
}
