package com.aomei.util.JCO3;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Properties;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.ext.DestinationDataProvider; 

public class JCO3 {// ���ӳ�

   static String ABAP_AS_POOLED = "ABAP_AS_WITH_POOL";
   static {
      Properties connectProperties = new Properties();
      connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, "172.16.0.188");
      connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR, "00");
      connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, "800");
      connectProperties.setProperty(DestinationDataProvider.JCO_USER, "zit100");
      connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, "123456789");
      connectProperties.setProperty(DestinationDataProvider.JCO_LANG, "en");
      connectProperties.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT, "10");
      connectProperties.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, "3");
      //createDataFile(ABAP_AS_POOLED, "jcoDestination", connectProperties);
   }

    static void createDataFile(String name, String suffix, Properties properties) {
      File cfg = new File(name + "." + suffix);
      if (!cfg.exists()) {
         try {
            FileOutputStream fos = new FileOutputStream(cfg, false);
            properties.store(fos, "for tests only !");
            fos.close();
         } catch (Exception e) {
            e.printStackTrace();
         }

      }

   }

 
   public static void connectWithPooled() throws JCoException {
      JCoDestination destination = JCoDestinationManager.getDestination(ABAP_AS_POOLED);
      System.out.println("Attributes:");
      System.out.println(destination.getAttributes());
   }
}

 
