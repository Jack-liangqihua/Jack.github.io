package com.oa.crm;

public class OAInfo {
	public String getCanDel() {
		return CanDel;
	}
	public void setCanDel(String canDel) {
		CanDel = canDel;
	}
	public String getRequestid() {
		return requestid;
	}
	public void setRequestid(String requestid) {
		this.requestid = requestid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	} 
	
	public String CanDel;
	public String requestid ;
	public String status ;
	public String lastname; 
}
