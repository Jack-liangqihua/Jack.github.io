package com.aomei.util;

public class XML2Obj {
}
