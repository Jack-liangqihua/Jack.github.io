package com.aomei.bo;

public class ItemTraval {

	

public String getChailv() {
	return chailv;
}
public void setChailv(String chailv) {
	this.chailv = chailv;
}
public String getChailvnama() {
	return chailvnama;
}
public void setChailvnama(String chailvnama) {
	this.chailvnama = chailvnama;
}
public String getBfkh() {
	return bfkh;
}
public void setBfkh(String bfkh) {
	this.bfkh = bfkh;
}
public String getBfry() {
	return bfry;
}
public void setBfry(String bfry) {
	this.bfry = bfry;
}
public String getWizhi() {
	return wizhi;
}
public void setWizhi(String wizhi) {
	this.wizhi = wizhi;
}
public String getZsjd() {
	return zsjd;
}
public void setZsjd(String zsjd) {
	this.zsjd = zsjd;
}
public String getKssj() {
	return kssj;
}
public void setKssj(String kssj) {
	this.kssj = kssj;
}
public String getJssj() {
	return jssj;
}
public void setJssj(String jssj) {
	this.jssj = jssj;
}
public String getBfmd() {
	return bfmd;
}
public void setBfmd(String bfmd) {
	this.bfmd = bfmd;
}
public String getJieguo() {
	return jieguo;
}
public void setJieguo(String jieguo) {
	this.jieguo = jieguo;
}

public String chailv;//	差旅	明细字段	单行文本框	整数	1.00
public String chailvnama;//	主题	明细字段	单行文本框	文本	2.00
public String bfkh;//	拜访客户	明细字段	单行文本框	文本	3.00
public String bfry;//	拜访人员	明细字段	单行文本框	文本	4.00
public String wizhi;//	位置	明细字段	单行文本框	文本	5.00
public String zsjd;//	住宿酒店	明细字段	单行文本框	文本	6.00
public String kssj;//	开始时间	明细字段	单行文本框	文本	7.00
public String jssj;//	结束时间	明细字段	单行文本框	文本	8.00
public String bfmd;//	拜访目的	明细字段	单行文本框	文本	9.00
public String jieguo;//	结果	明细字段	单行文本框	文本	10.00

	
	
}
