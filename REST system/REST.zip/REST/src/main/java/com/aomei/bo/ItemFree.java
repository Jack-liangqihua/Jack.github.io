package com.aomei.bo;
 

public class ItemFree {
	 

 
	 
	public int getPosnr() {
		return posnr;
	}
	public void setPosnr(int posnr) {
		this.posnr = posnr;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getBxxm() {
		return bxxm;
	}
	public void setBxxm(String bxxm) {
		this.bxxm = bxxm;
	}
	public String getYuanyin() {
		return yuanyin;
	}
	public void setYuanyin(String yuanyin) {
		this.yuanyin = yuanyin;
	}
	public String getJine() {
		return jine;
	}
	public void setJine(String jine) {
		this.jine = jine;
	}
	public int 	  posnr;
	public String flag;
	public String bxxm;
	public String yuanyin;
	public String jine; 
	 
	
	 
  

}
