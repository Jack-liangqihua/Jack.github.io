package com.example.demo;

import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.aomei.util.LogFormatter;

public class TestLog {

	public static void main(String[] args) {}
}
